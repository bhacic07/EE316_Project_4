const hangmanImage = document.querySelector(".hangman-box img");
const wordDisplay = document.querySelector(".word-display");
const guessesText = document.querySelector(".guesses-text");
const keyboardDiv = document.querySelector(".keyboard");
const gameModel = document.querySelector(".game-model");
const playAgainBtn = document.querySelector(".play-again");


let currentWord, correctLetters, wrongGuessCount, remainingGuessCount;
const maxGuesses = 6;
let wordsUsed = [];

// Update the resetGame function to send the initial hidden word and clear the LCD
const resetGame = async (resetWordsUsed = true) => {
    correctLetters = [];
    wrongGuessCount = 0;
    remainingGuessCount = 6;
    hangmanImage.src = `hangman${wrongGuessCount}.png`
    guessesText.innerText = `${wrongGuessCount} / ${maxGuesses}`;
    keyboardDiv.querySelectorAll("button").forEach(btn => btn.disabled = false);
    wordDisplay.innerHTML = currentWord.split("").map(() => `<li class="letter"></li>`).join("");
    gameModel.classList.remove("show");
    if (resetWordsUsed) {
        wordsUsed = []; // Reset the array of words used only if resetWordsUsed is true
    }
    
    // Initialize hiddenWord with underscores
    hiddenWord = currentWord.replace(/[a-z]/g, '_');
    // Send the initial hiddenWord and clear the LCD
    await WritetoSerial(hiddenWord);
    await clearLCD();
    await WritetoSerial(remainingGuessCount); 
}

// Function to read words from text file (async because reading from file takes some time. js can execute other code while waiting for this to finish)
async function ReadFromFileandSelectRandomWord() {
    try {
        const response = await fetch('EnglishWords.txt');
        const text = await response.text();
        const words = text.split('\n');
        const randomWord = words[Math.floor(Math.random() * words.length)];
        currentWord = randomWord;
        resetGame();
    } catch (error) {
        console.error("Error reading words from file.", error); 
        }
}

const gameOver =  async (isVictory) => {
    wordsUsed.push(currentWord);
    // after 600ms of game completion show model with relevent details
    setTimeout(() => {
        const modelText = isVictory ? `Well done! You have solved` : `Sorry! The correct word was:`;
        gameModel.querySelector("img").src = `images/${isVictory ? 'victory' : 'lost'}.png`;
        gameModel.querySelector("h4").innerText = `${isVictory ? 'Congrats!' : 'Game Over!'}`;
        gameModel.querySelector("p").innerHTML = `${modelText} <b>${currentWord}</b>. You have solved <b>${wordsUsed.length}</b> puzzles out of 1000`;
        gameModel.classList.add("show");

        // Sending game outcome logic to the serial port
        const gameOutcome = isVictory ? `Well done! You have solved ${wordsUsed.length} puzzles out of 1000` : `Sorry! The correct word was: ${currentWord}. You have solved ${wordsUsed.length} puzzles out of 1000`;
        WritetoSerial(gameOutcome);

    //   if (!isVictory && resetWordsUsed) {
    //      resetGame(false); // Only reset the wordsUsed array if it's not a victory
    // }

    }, 300);
}

// Update the initGame function to send the updated hidden word and clear the LCD each time it's updated
const initGame = async (button, clickedLetter) => {
    if (remainingGuessCount === undefined) {
        // If remainingGuessCount is undefined (i.e., game just started), send the initial value (6) to the serial port
        await WritetoSerial(maxGuesses);
    }

    let letterFound = false; // Flag to indicate if the clicked letter is found in the current word

    if(currentWord.includes(clickedLetter)) {
        [...currentWord].forEach((letter, index) => {
            if(letter === clickedLetter) {
                correctLetters.push(letter);
                // Update the hidden word to reveal the correct letter
                hiddenWord = hiddenWord.substring(0, index) + letter + hiddenWord.substring(index + 1);
                wordDisplay.querySelectorAll('li')[index].innerText = letter;
                wordDisplay.querySelectorAll('li')[index].classList.add("guessed");
                letterFound = true; // Set the flag to true
            }
        });
    } else {
        wrongGuessCount++;
        remainingGuessCount--;
        hangmanImage.src = `hangman${wrongGuessCount}.png`
    }

    // If the clicked letter is found in the word, update the hidden word and clear the LCD
    if (letterFound) {
        await WritetoSerial(hiddenWord);
        await clearLCD();
    }

    button.disabled = true;
    guessesText.innerText = `${wrongGuessCount} / ${maxGuesses}`;
    
    console.log("Remaining Guess Count:", remainingGuessCount);
    await WritetoSerial(remainingGuessCount); // Send the updated value to the port

    if(wrongGuessCount === maxGuesses) return gameOver(false);
    if(correctLetters.length === currentWord.length) return gameOver(true);
}

window.addEventListener('keydown', async function(event) {
    if (gameModel.classList.contains('show')) {
        const key = event.key.toLowerCase();
        if (key === 'y') {
            playAgainBtn.click();
            // gameOver(false, false); // Pass false to prevent resetting wordsUsed on 'Y'
        } else if (key === 'n') {
           const over = gameModel.querySelector("h4").innerText = "GAME OVER!";
            gameModel.querySelector("p").innerText = "";
            await WritetoSerial(over);
          //  gameOver(false, true); // Reset the game when 'N' is pressed
            // You may want to reset the game here
            //await resetGame(); // If you want to reset the game when 'N' is pressed
        }
    } else {
        const key = event.key.toLowerCase();
        if (key.match(/[a-z]/)) {
            const correspondingButton = keyboardDiv.querySelector(`button[data-key="${key}"]`);
            if (correspondingButton) {
                correspondingButton.click();
            } 
           
        }
    }
});

//creating keyboard buttons
for (let i = 97; i <= 122; i++) {
    const button = document.createElement("button");
    button.innerText = String.fromCharCode(i);
    button.dataset.key = String.fromCharCode(i);
    keyboardDiv.appendChild(button);
    button.addEventListener("click", e => initGame(e.target, String.fromCharCode(i)));
}

// Function to connect to serial port
async function connectSerial() {
    try {
        const port = await navigator.serial.requestPort();     
        if (!port) {
            throw new Error("Serial port is not available.");
        }
        
        await port.open({ baudRate: 9600, parity: 'none', dataBits: 8, stopBits: 1 });

        const reader = port.readable.getReader();

        // Continuously read data from the serial port
        while (true) {
            const { value, done } = await reader.read();
            if (done) break;
            const receivedData = new TextDecoder().decode(value);
            handleReceivedData(receivedData);
        }
    } catch (error) {
        console.error("Error accessing serial port:", error);
    }
}

// Function to send the clear LCD command
async function clearLCD() {
    try {
        const ports = await navigator.serial.getPorts();
        if (!ports || ports.length === 0) {
            throw new Error("No serial ports available.");
        }
        
        const port = ports[0];

        if (!port.writable) {
            throw new Error("Serial port does not support writing.");
        }  

        if (port.writable.locked) {
            throw new Error("WritableStream is locked.");
        }

        // Send the clear LCD command (e.g., "01" in hex)
        const clearCommand = "01";
        const writer = port.writable.getWriter();
        const data = new TextEncoder().encode(clearCommand);
        await writer.write(data);
        await writer.close();
        console.log("LCD cleared.");
    } catch (error) {
        console.error("Error accessing serial port:", error);
    }
}

// Function to connect to serial port
async function WritetoSerial(message) {
    try {
        const ports = await navigator.serial.getPorts();     
        console.log(ports);
        if (!ports || ports.length === 0) {
            throw new Error("No serial ports available.");
        }
        
        // Select the first available port
        const port = ports[0];

        if (!port.writable) {
            throw new Error("Serial port does not support writing.");
        }  

        // Check if the WritableStream is locked
        if (port.writable.locked) {
            throw new Error("WritableStream is locked.");
        }

        // Write data to the serial port
       const writer = port.writable.getWriter();
        const data = new TextEncoder().encode(message);
        await writer.write(data);
        console.log("Data Sent to Port: ", message);
        await writer.close();
    } catch (error) {
        console.error("Error accessing serial port:", error);
    }
    
}

// Function to handle received data from the serial port
function handleReceivedData(data) {
    const keys = data.trim().split(""); // Split data into individual characters
    keys.forEach(key => {
        const correspondingButton = keyboardDiv.querySelector(`button[data-key="${key}"]`);
        if (correspondingButton) {
            correspondingButton.click();
            if (gameModel.classList.contains('show')) {
                if (keys === 'y') {
                    playAgainBtn.click();
                } else if (keys === 'n') { // n doesnt work fix later
                    gameModel.querySelector("h4").innerText = "GAME OVER!";
                    gameModel.querySelector("p").innerText = "";
                  //  await WritetoSerial(remainingGuessCount);
                }
            }
        }
    });
    console.log("Received data from PS2 keyboard:", data);
}


connectSerial(); 
ReadFromFileandSelectRandomWord();
playAgainBtn.addEventListener("click", ReadFromFileandSelectRandomWord);

